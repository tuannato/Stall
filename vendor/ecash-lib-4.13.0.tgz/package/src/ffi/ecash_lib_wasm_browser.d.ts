/* tslint:disable */
/* eslint-disable */
/**
* Verify a signature for the given cryptographic algorithm.
* Intended to be used in X509 certificate verification.
* Throw an exception if the algorithm is not supported.
* @param {string} algo_oid
* @param {string | undefined} params
* @param {Uint8Array} sig
* @param {Uint8Array} msg
* @param {Uint8Array} pk
*/
export function publicKeyCryptoVerify(algo_oid: string, params: string | undefined, sig: Uint8Array, msg: Uint8Array, pk: Uint8Array): void;
/**
* Throw an exception if the given algo is not supported, otherwise do nothing.
* @param {string} algo_oid
* @param {string | undefined} [params]
*/
export function publicKeyCryptoAlgoSupported(algo_oid: string, params?: string): void;
/**
* Calculate SHA512(data).
* @param {Uint8Array} data
* @returns {Uint8Array}
*/
export function sha512(data: Uint8Array): Uint8Array;
/**
* Calculate SHA256(SHA256(data)).
* @param {Uint8Array} data
* @returns {Uint8Array}
*/
export function sha256d(data: Uint8Array): Uint8Array;
/**
* Calculate SHA256(data).
* @param {Uint8Array} data
* @returns {Uint8Array}
*/
export function sha256(data: Uint8Array): Uint8Array;
/**
* Calculate RIPEMD160(SHA256(data)), commonly used as address hash.
* @param {Uint8Array} data
* @returns {Uint8Array}
*/
export function shaRmd160(data: Uint8Array): Uint8Array;
/**
* ECC signatures with libsecp256k1.
*/
export class Ecc {
  free(): void;
/**
* Create a new Ecc instance.
*/
  constructor();
/**
* Derive a public key from secret key.
* @param {Uint8Array} seckey
* @returns {Uint8Array}
*/
  derivePubkey(seckey: Uint8Array): Uint8Array;
/**
* Sign an ECDSA signature.
* @param {Uint8Array} seckey
* @param {Uint8Array} msg
* @returns {Uint8Array}
*/
  ecdsaSign(seckey: Uint8Array, msg: Uint8Array): Uint8Array;
/**
* Verify an ECDSA signature.
* @param {Uint8Array} sig
* @param {Uint8Array} msg
* @param {Uint8Array} pk
*/
  ecdsaVerify(sig: Uint8Array, msg: Uint8Array, pk: Uint8Array): void;
/**
* Sign a Schnorr signature.
* @param {Uint8Array} seckey
* @param {Uint8Array} msg
* @returns {Uint8Array}
*/
  schnorrSign(seckey: Uint8Array, msg: Uint8Array): Uint8Array;
/**
* Verify a Schnorr signature.
* @param {Uint8Array} sig
* @param {Uint8Array} msg
* @param {Uint8Array} pk
*/
  schnorrVerify(sig: Uint8Array, msg: Uint8Array, pk: Uint8Array): void;
/**
* Return whether the given secret key is valid, i.e. whether is of correct
* length (32 bytes) and is on the curve.
* @param {Uint8Array} seckey
* @returns {boolean}
*/
  isValidSeckey(seckey: Uint8Array): boolean;
/**
* Add a scalar to a secret key.
* @param {Uint8Array} a
* @param {Uint8Array} b
* @returns {Uint8Array}
*/
  seckeyAdd(a: Uint8Array, b: Uint8Array): Uint8Array;
/**
* Multiply a secret key by a scalar (a * b).
* @param {Uint8Array} a
* @param {Uint8Array} b
* @returns {Uint8Array}
*/
  seckeyMul(a: Uint8Array, b: Uint8Array): Uint8Array;
/**
* Negate a secret key (−a mod n).
* @param {Uint8Array} a
* @returns {Uint8Array}
*/
  seckeyNegate(a: Uint8Array): Uint8Array;
/**
* Add a scalar to a public key (adding G*b).
* @param {Uint8Array} a
* @param {Uint8Array} b
* @returns {Uint8Array}
*/
  pubkeyAdd(a: Uint8Array, b: Uint8Array): Uint8Array;
/**
* Multiply a public key by a scalar (P * b).
* @param {Uint8Array} a
* @param {Uint8Array} b
* @returns {Uint8Array}
*/
  pubkeyMul(a: Uint8Array, b: Uint8Array): Uint8Array;
/**
* Add two public keys (P + Q). Errors if the sum is the point at infinity.
* @param {Uint8Array} a
* @param {Uint8Array} b
* @returns {Uint8Array}
*/
  pubkeyCombine(a: Uint8Array, b: Uint8Array): Uint8Array;
/**
* Decompress a compressed public key to 65-byte uncompressed form
* (0x04||x||y).
* @param {Uint8Array} pk
* @returns {Uint8Array}
*/
  uncompressPk(pk: Uint8Array): Uint8Array;
/**
* Create a compact ECDSA signature (65 bytes), which allows reconstructing
* the used public key.
* The format is one header byte, followed by two times 32 bytes for the
* serialized r and s values.
* The header byte: 0x1B = first key with even y,
*                  0x1C = first key with odd y,
*                  0x1D = second key with even y,
*                  0x1E = second key with odd y,
*                  add 0x04 for compressed keys.
* @param {Uint8Array} seckey
* @param {Uint8Array} msg
* @returns {Uint8Array}
*/
  signRecoverable(seckey: Uint8Array, msg: Uint8Array): Uint8Array;
/**
* Recover the public key of a signature signed by signRecoverable.
* @param {Uint8Array} sig
* @param {Uint8Array} msg
* @returns {Uint8Array}
*/
  recoverSig(sig: Uint8Array, msg: Uint8Array): Uint8Array;
}
/**
* Instance to calculate SHA256 in a streaming fashion
*/
export class Sha256H {
  free(): void;
/**
* Create new hasher instance
*/
  constructor();
/**
* Feed bytes into the hasher
* @param {Uint8Array} data
*/
  update(data: Uint8Array): void;
/**
* Finalize the hash and return the result
* @returns {Uint8Array}
*/
  finalize(): Uint8Array;
/**
* Clone the hasher
* @returns {Sha256H}
*/
  clone(): Sha256H;
}
/**
* Instance to calculate SHA512 in a streaming fashion
*/
export class Sha512H {
  free(): void;
/**
* Create new hasher instance
*/
  constructor();
/**
* Feed bytes into the hasher
* @param {Uint8Array} data
*/
  update(data: Uint8Array): void;
/**
* Finalize the hash and return the result
* @returns {Uint8Array}
*/
  finalize(): Uint8Array;
/**
* Clone the hasher
* @returns {Sha512H}
*/
  clone(): Sha512H;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly ecc_new: () => number;
  readonly ecc_derivePubkey: (a: number, b: number, c: number, d: number) => void;
  readonly ecc_ecdsaSign: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_ecdsaVerify: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
  readonly ecc_schnorrSign: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_schnorrVerify: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => void;
  readonly ecc_isValidSeckey: (a: number, b: number, c: number) => number;
  readonly ecc_seckeyAdd: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_seckeyMul: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_seckeyNegate: (a: number, b: number, c: number, d: number) => void;
  readonly ecc_pubkeyAdd: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_pubkeyMul: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_pubkeyCombine: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_uncompressPk: (a: number, b: number, c: number, d: number) => void;
  readonly ecc_signRecoverable: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly ecc_recoverSig: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly __wbg_ecc_free: (a: number) => void;
  readonly publicKeyCryptoVerify: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => void;
  readonly publicKeyCryptoAlgoSupported: (a: number, b: number, c: number, d: number, e: number) => void;
  readonly sha512h_new: () => number;
  readonly sha512h_update: (a: number, b: number, c: number) => void;
  readonly sha512h_finalize: (a: number, b: number) => void;
  readonly sha512h_clone: (a: number) => number;
  readonly __wbg_sha512h_free: (a: number) => void;
  readonly sha256h_new: () => number;
  readonly sha256h_update: (a: number, b: number, c: number) => void;
  readonly sha256h_finalize: (a: number, b: number) => void;
  readonly sha256h_clone: (a: number) => number;
  readonly __wbg_sha256h_free: (a: number) => void;
  readonly sha512: (a: number, b: number, c: number) => void;
  readonly sha256d: (a: number, b: number, c: number) => void;
  readonly sha256: (a: number, b: number, c: number) => void;
  readonly shaRmd160: (a: number, b: number, c: number) => void;
  readonly ecash_secp256k1_context_create: (a: number) => number;
  readonly ecash_secp256k1_context_destroy: (a: number) => void;
  readonly secp256k1_default_illegal_callback_fn: (a: number, b: number) => void;
  readonly secp256k1_default_error_callback_fn: (a: number, b: number) => void;
  readonly ring_core_0_17_14__bn_mul_mont: (a: number, b: number, c: number, d: number, e: number, f: number) => void;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_export_0: (a: number, b: number) => number;
  readonly __wbindgen_export_1: (a: number, b: number, c: number) => void;
  readonly __wbindgen_export_2: (a: number, b: number, c: number, d: number) => number;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {SyncInitInput} module
*
* @returns {InitOutput}
*/
export function initSync(module: SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: InitInput | Promise<InitInput>): Promise<InitOutput>;
