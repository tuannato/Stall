export const ECASH_LIB_WASM_BASE64: string;
