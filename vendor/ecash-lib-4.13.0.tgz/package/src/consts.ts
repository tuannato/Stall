// Copyright (c) 2024 The Bitcoin developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

/** Default dust limit on the eCash network. */
export const DEFAULT_DUST_SATS = 546n;
/** Default fee per kB on the eCash network. */
export const DEFAULT_FEE_SATS_PER_KB = 1000n;

/** Derivation path for non-HD token aware XEC wallets, like ecash-wallet or Cashtab */
export const XEC_TOKEN_AWARE_DERIVATION_PATH = `m/44'/1899'/0'/0/0`;

/**
 * Confirmations required before coinbase utxos
 * are spendable
 *
 * On eCash, coinbase utxos may be
 *
 * - mining rewards
 * - staking rewards
 * - IFP rewards
 */
export const COINBASE_MATURITY = 100;
/**
 * As of May 5, 2025, the max bytes permitted in an OP_RETURN
 * output on the eCash (XEC) network
 *
 * NB SLP spec works within this limit, ALP spec supports actions
 * beyond this limit. For now, ecash-wallet is written accounting
 * for this limit in ALP token action validation.
 */
export const OP_RETURN_MAX_BYTES = 223;

/**
 * The node will throw an error on broadcasting a tx
 * with serSize() greater than this value in bytes
 */
export const MAX_TX_SERSIZE = 100_000;

/**
 * Maximum byte size of script numbers when interpreting Script.
 * Mirrors MAX_SCRIPTNUM_BYTE_SIZE in src/script/script.h.
 */
export const MAX_SCRIPTNUM_BYTE_SIZE = 8;

/** Max pubkeys per multisig script. Matches MAX_PUBKEYS_PER_MULTISIG in src/script/script.h. */
export const MAX_PUBKEYS_PER_MULTISIG = 20;

/**
 * Upper bound on ECDSA `vchSig` size (strict DER + sighash byte) for fee / size
 * estimation with {@link EccDummy}. Matches script validation: DER ≤ 72 bytes,
 * then one sighash byte → max 73. Slightly above typical sizes (~71–72) and
 * above the wallet dummy (72-byte `vchSig` in Bitcoin ABC); avoids underestimating.
 *
 * Since 1 sat/byte is both the min fee and a typical fee, do not assume slack
 */
export const ECDSA_SIG_ESTIMATE_BYTES = 73;

/** Schnorr signature size in bytes including sighash flag, for fee estimation. */
export const SCHNORR_SIG_ESTIMATE_BYTES = 65;

// The size in bytes of a p2pkh output
export const P2PKH_OUTPUT_SIZE = 34;
